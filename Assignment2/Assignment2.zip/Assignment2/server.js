const http = require("http");
const fs = require('fs');
let status, message;
const readAndServer = function (req, res) {
    switch (req.method) {
        case "GET":
            if (req.url == "/index".toLocaleLowerCase() || req.url == "/") {
                res.setHeader("Content-Type", "text/html");
                res.writeHead(status);
                res.end(message);
            }
            else if (req.url.toLocaleLowerCase() == "/page2") {
                fs.readFile(__dirname + "//page2.html", function (err, buffer) {
                    res.setHeader("Content-Type", "text/html");
                    res.writeHead(200);
                    res.end(buffer)
                });
            }
            else if (req.url.toLocaleLowerCase() == "/page1") {
                fs.readFile(__dirname + "//page1.html", function (err, buffer) {
                    res.setHeader("Content-Type", "text/html");
                    res.writeHead(200);
                    res.end(buffer)
                });
            }
            else{
                res.writeHead(500);
                res.end("No Page Found");
            }

         
        break;
        case "POST":
            res.setHeader("Content-Type", "application/json");
            res.writeHead(200);
            res.end('{"Name":"Muhammad","Awesome":"Very"}');
        break;
    

    }
};


const GET = fs.readFile(__dirname + "//index.html", function (err, buffer) {

    if (err) {
        status = "500";
        message = "page can't be found";
    }
    else {
        status = "200";
        message = buffer;
    }

});


const server = http.createServer(readAndServer);
server.listen(8000);